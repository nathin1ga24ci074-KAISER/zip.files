#!/usr/bin/env python3
"""
Fetch and pin the official Public Suffix List bytes.
This script does not read, modify, parse, or otherwise touch any dataset files.

Usage:
  python fetch_official_psl.py --out ../psl_pending/public_suffix_list.dat

The script records exact downloaded bytes, UTC retrieval timestamp, SHA-256,
VERSION and COMMIT headers, response URL, Last-Modified and ETag when present.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path
from urllib.request import Request, urlopen

OFFICIAL_URL = "https://publicsuffix.org/list/public_suffix_list.dat"

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="../psl_pending/public_suffix_list.dat")
    args = ap.parse_args()
    out = Path(args.out).resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    req = Request(OFFICIAL_URL, headers={
        "User-Agent": "PhishRadar-PROMPT7B-handoff/1.0",
        "Accept": "text/plain,*/*",
    })
    with urlopen(req, timeout=60) as response:
        raw = response.read()
        response_url = response.geturl()
        headers = dict(response.headers.items())

    text = raw.decode("utf-8")
    version = None
    commit = None
    for line in text.splitlines()[:40]:
        if line.startswith("// VERSION:"):
            version = line.split(":", 1)[1].strip()
        elif line.startswith("// COMMIT:"):
            commit = line.split(":", 1)[1].strip()

    out.write_bytes(raw)
    meta = {
        "official_url": OFFICIAL_URL,
        "response_url": response_url,
        "downloaded_at_utc": dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z"),
        "size_bytes": len(raw),
        "sha256": hashlib.sha256(raw).hexdigest(),
        "version": version,
        "commit": commit,
        "last_modified": headers.get("Last-Modified"),
        "etag": headers.get("ETag"),
        "icann_section_present": "===BEGIN ICANN DOMAINS===" in text,
        "private_section_present": "===BEGIN PRIVATE DOMAINS===" in text,
        "raw_file": str(out),
    }
    meta_path = out.with_name("public_suffix_list_metadata.json")
    meta_path.write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(meta, indent=2))

if __name__ == "__main__":
    main()
