# PROMPT 7B — Final Domain and URL Integrity Audit

Perform the user's requested final integrity audit using the original five dataset files
in `original_datasets/` and an exactly downloaded, version-pinned official PSL.

Requirements:
1. Download and pin the official PSL bytes from https://publicsuffix.org/list/public_suffix_list.dat.
2. Record exact UTC download time, size, SHA-256, VERSION and COMMIT headers.
3. Revalidate the existing SHA-256 manifest without modifying originals.
4. Recalculate eTLD+1 using ICANN-only and ICANN+PRIVATE rules.
5. Report DNS hostnames, IPv4 and IPv6 literals, scheme-less URLs, malformed and missing
   URLs separately, including class-wise breakdowns.
6. Investigate all within-LegitPhish domains appearing in both classes; do not assume
   the previously mentioned count of 11 is correct.
7. Compare raw, conservative canonical and request-equivalence URL keys.
8. Recalculate all six pairwise URL, hostname, IP and domain overlap matrices.
9. Reconcile changes against `previous_audit/PROMPT7_Dataset_Acquisition_File_Audit.xlsx`.
10. Produce a reproducible workbook, methodology, PSL metadata and updated manifest.

Restrictions: no model training, no LLM calls, no live URL visits, no dataset merging,
no label correction, no modification/deletion of original files, and no final dataset
selection.

The exact detailed PROMPT 7B text should be supplied in the new conversation if needed;
the above is a concise handoff checklist, not a replacement for the user's full prompt.
