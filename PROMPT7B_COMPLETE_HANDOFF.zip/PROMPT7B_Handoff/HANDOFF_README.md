# PhishRadar — PROMPT 7B Handoff Package

Handoff created: 2026-11-17T13:27:59Z

## Purpose

This package transfers the original dataset inputs and completed PROMPT 7 audit material
to another ChatGPT conversation for continuation of PROMPT 7B.

**No dataset was rerun, transformed, rewritten, merged, or modified to prepare this
handoff.** Original files were copied byte-for-byte into `original_datasets/`.

## Package contents

### 1. Original dataset files

| Exact filename | Dataset / release | Location |
|---|---|---|
| `phiusiil+phishing+url+dataset.zip` | PhiUSIIL v2 candidate | `original_datasets/` |
| `Dataset.csv` | URL-Phish v2 | `original_datasets/` |
| `All_Features_threshold90.xlsx` | CompPhish v4 | `original_datasets/` |
| `Mapping_File.xlsx` | CompPhish v4 | `original_datasets/` |
| `url_features_extracted1.csv` | LegitPhish v2 candidate | `original_datasets/` |

The original PhiUSIIL ZIP is preserved; its contents are not extracted or modified in
this handoff. The CompPhish HTML archive was not part of the uploaded inputs and is not
included.

### 2. Completed prior audit

`previous_audit/PROMPT7_Dataset_Acquisition_File_Audit.xlsx`

This is the PROMPT 7 workbook created in the prior conversation. It contains the
previous file-level counts, hashes, overlap results and caveats. Treat its domain
counts as **preliminary** because its PSL basis was the built-in `libpsl 0.21.2`
snapshot dated 2023-10-01, not the requested current official PSL snapshot.

### 3. Supporting reference uploads

`reference_material/` contains the three supporting text/markdown uploads that were
available in the prior conversation. They are preserved as reference material, not
dataset inputs.

### 4. PSL acquisition helper

`scripts/fetch_official_psl.py` downloads only the official PSL file and records
metadata. It does not read or modify the datasets.

`psl_pending/PSL_NOT_ACQUIRED.txt` documents the acquisition limitation.

### 5. Task checklist

`PROMPT7B_TASK_CHECKLIST.md` summarizes the remaining PROMPT 7B work.

## PSL version, commit and timestamp — important limitation

A web-rendered copy of the official endpoint exposed:

- URL: `https://publicsuffix.org/list/public_suffix_list.dat`
- VERSION header: `2026-07-25_14-20-03_UTC`
- COMMIT header: `e1b8015c3b2f0f4f8c18659c2480fc1a22c07b20`

However, this was a web-crawled rendering (reported as crawled approximately three
months before this handoff), not the raw downloaded file. It is **not verified as the
latest snapshot on the handoff date**.

An attempt to retrieve the raw official bytes from the execution environment failed
with DNS/network resolution failure. Consequently:

- Exact `public_suffix_list.dat` bytes are **not included**.
- PSL SHA-256 is **not available**.
- Exact PSL download timestamp is **not available**.
- No PROMPT 7B calculations against that PSL have been completed.
- Do not describe the above version/commit as the handoff's acquired PSL snapshot.

Run `scripts/fetch_official_psl.py` in a network-enabled environment. The script will
save `public_suffix_list.dat` and `public_suffix_list_metadata.json` alongside it.
Verify the actual VERSION/COMMIT headers and preserve the metadata.

## Completed steps — verified from prior work

- Five original dataset files were available and copied into this package.
- The previous PROMPT 7 audit workbook was included.
- SHA-256 values for the five uploaded dataset files were calculated in the prior
  conversation and are reproduced in `SHA256_MANIFEST.csv`.
- The prior audit inspected CSV/XLSX schemas and reported row counts and labels.
- The prior audit calculated preliminary exact/canonical URL and domain overlaps.
- The CompPhish HTML archive was excluded.
- No training, LLM calls, application development, live phishing-site visits or
  automatic dataset merging occurred.

## Preliminary / unverified results

The prior PROMPT 7 workbook reported, among other findings:

- PhiUSIIL v2: 235,795 rows.
- URL-Phish v2: 116,600 rows, including 1,369 exact duplicate URL rows.
- CompPhish v4: 15,358 rows; feature and mapping files reportedly aligned.
- LegitPhish v2 candidate: 101,219 rows with one missing class label.
- A large PhiUSIIL–LegitPhish overlap: 36,936 exact URLs and 36,511 shared eTLD+1 domains.
- A URL label conflict between URL-Phish and CompPhish was reported for
  `https://kakaku.com/`.

These are **prior-audit results**, not independently rerun in this handoff. Domain
counts were based on an older built-in PSL and need recalculation. The prior report's
cross-class LegitPhish explanation and domain-count arithmetic remain to be checked
against the actual records and a pinned current PSL.

## Pending steps

1. Acquire exact official PSL bytes and metadata using the included script.
2. Revalidate all original SHA-256 hashes.
3. Recalculate DNS hostname, IPv4/IPv6, scheme-less, malformed and missing URL counts.
4. Calculate ICANN-only and ICANN+PRIVATE registrable-domain counts.
5. Verify all LegitPhish cross-class domains and the previously discussed count of 11.
6. Recalculate raw, conservative canonical and request-equivalence URL counts.
7. Recalculate all six pairwise URL, hostname, IP and registrable-domain overlap matrices.
8. Reconcile updated results with the PROMPT 7 workbook.
9. Produce the completed PROMPT 7B workbook, methodology and updated manifest.

## Errors and unresolved findings

- PSL raw download failed because the environment could not resolve the official host.
- No PSL bytes or PSL checksum were obtained.
- No PROMPT 7B script outputs, intermediate calculations or completed workbook existed
  in the prior conversation to include.
- Original dataset download dates were not recorded in the source files; the previous
  report recorded inspection date 2026-11-16, not a verified download date.
- The uploaded LegitPhish filename differs from the publisher's dataset naming; its
  provenance should be checked against the exact release download.
- PSL snapshot age may change eTLD+1 grouping and pairwise overlap counts.
- The prior domain counts and cross-class explanation must not be treated as final.

## Integrity and manifest

`SHA256_MANIFEST.csv` lists each packaged payload file (excluding the manifest itself
and the ZIP archive) with its exact byte size and SHA-256. It also records the prior
PROMPT 7 hashes for the five original dataset files.

After extracting the ZIP, verify the manifest before continuing. Keep the originals
read-only and write all PROMPT 7B outputs to a separate output directory.

## Recommended opening instruction in the new conversation

"Please inspect the attached PROMPT7B handoff ZIP and README. Continue the PROMPT 7B
audit from the pending steps. First verify the packaged files and acquire the exact
official PSL bytes. Do not rerun or modify originals except as required for read-only
analysis, and clearly distinguish previous preliminary results from newly verified
results."
