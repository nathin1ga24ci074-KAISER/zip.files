## PROMPT 1 — MASTER CONTEXT AND RESEARCH INSTRUCTIONS

I am a third-year Computer Science Engineering student specialising in AI & ML. I am developing a research-oriented academic project on phishing URL detection.

I am continuing this project in a new ChatGPT conversation. You must act as my research supervisor, machine learning researcher, cybersecurity researcher, algorithm designer and technical development guide.

Your job is not simply to help me build a phishing detection application. Your job is to help me identify a defensible research problem, formulate a meaningful contribution, design experiments that can demonstrate its value, and then implement it.

### 1. Project background

My earlier project was called PhishLens:

"AI-Based Multi-Feature Phishing Website Detection and Risk Analysis."

The earlier implementation included:

- URL preprocessing.
- URL and webpage feature extraction.
- Logistic Regression, Random Forest and XGBoost experimentation.
- Probability calibration.
- SHAP explainability.
- Risk scoring.
- Two-stage machine learning and LLM analysis.
- Selective escalation of uncertain URLs.
- Groq and Gemini integration.

My mentor criticised the project because:

- XGBoost is an established algorithm.
- Combining existing algorithms does not automatically constitute research novelty.
- Adding an LLM to a traditional phishing detector is not automatically a novel contribution.
- The project needs a genuine research problem and measurable improvement.

I therefore decided to reconsider the research direction and rebuild the project from scratch after completing the research and design.

Do not assume that the previous implementation must be retained.

### 2. Provisional research direction

The current working title is:

"Risk-Aware and Budget-Constrained Two-Stage AI Framework for Reliable Phishing URL Detection."

The project name PhishRadar is provisional. Do not assume it is final or that its name is unique.

The central research question is:

Given a limited AI inference budget, how should a phishing detection system decide which URLs require further AI analysis, while controlling security risk and maintaining reliability when the data distribution changes?

The project should investigate the intersection of:

1. Phishing-specific false-negative risk.
2. Limited AI inference capacity and cost.
3. Distribution shift and generalisation.
4. Uncertainty in the escalation/rejector mechanism.
5. Errors made by the AI expert itself.

This is a research direction, not a proven novelty claim.

### 3. Proposed two-stage concept

**Stage 1 — Traditional phishing detection**

- Process the submitted URL.
- Extract appropriate URL features.
- Use a lightweight machine learning model.
- Produce a prediction and calibrated confidence estimate.
- Identify relevant evidence and uncertainty.

**Research component — Risk-aware escalation policy**

Decide whether the URL should:

- Be handled by Stage 1.
- Be sent to Stage 2.
- Be marked uncertain or require investigation.

The policy must consider security risk, inference budget, distribution changes and its own uncertainty.

**Stage 2 — AI re-evaluation**

- Analyse only selected URLs.
- Receive the URL and relevant available evidence.
- Independently assess the case.
- Be allowed to disagree with Stage 1.
- Never invent domain reputation, WHOIS records, certificate details, website content or other unavailable evidence.
- Return structured results with evidence and limitations.

The AI must be treated as a fallible expert, not a perfect authority.

**Final output**

- LEGITIMATE
- PHISHING
- UNCERTAIN / NEEDS INVESTIGATION

### 4. Candidate mathematical formulation

The current candidate formulation is:

Let:

- x = submitted URL and available evidence.
- y = actual class, phishing or legitimate.
- h(x) = Stage 1 prediction.
- π(x) ∈ {0,1} = escalation policy.
- g(x) = Stage 2 AI assessment.
- c_AI(x) = actual or estimated AI inference cost.
- B = available AI inference budget.
- ŷ_π(x) = final system prediction.

Candidate objective:

minimize:

E[L_security(ŷ_π(X), Y)]

subject to:

E[c_AI(X)π(X)] ≤ B

and:

FNR_Dk(π) ≤ α_k, for k = 1,...,K.

This is not a frozen formulation. You must critically investigate whether existing research already solves this problem.

Do not simply accept the equations. Examine the definitions, assumptions, feasibility, guarantees and practical implications.

### 5. Research already identified

The following research areas and papers have already been identified. You must continue from them rather than treating the literature review as completely empty.

**Learning to defer**

- Mozannar & Sontag (2020), Consistent Estimators for Learning to Defer to an Expert.
- Narasimhan et al. (2022), Post-hoc Estimators for Learning to Defer to an Expert.
- Verma et al. (2023), Learning to Defer to Multiple Experts.
- Mao et al. (2023), Two-Stage Learning to Defer with Multiple Experts.

**Selective classification and distribution shift**

- Franc, Prusa & Voracek (2023), Optimal Strategies for Reject Option Classifiers.
- Liang, Peng & Sun (2024), Selective Classification Under Distribution Shifts.

**Risk control and constrained deferral**

- Angelopoulos et al. (2024), Conformal Risk Control.
- Charusaie & Samadi (2024), A Unifying Post-Processing Framework for Multi-Objective Learn-to-Defer Problems.

**LLM routing and cascading**

- Dekoninck, Baader & Vechev (2025), A Unified Approach to Routing and Cascading for LLMs.
- Markovic-Voronov et al. (2026), Robust Batch-Level Query Routing for Large Language Models under Cost and Capacity Constraints.

**Uncertain rejectors**

- Fang (2026), Learning to Defer with an Uncertain Rejector via Conformal Prediction.

**Phishing-specific research**

- Nandhini, Saranya & Jegathambal (2026), PhishLens: Calibration-Aware Selective Routing with Verified Local-LLM Evidence Selection for Phishing Website Detection.
- Trad & Chehab (2026), Toward Accurate and Cost-Effective LLM Agents via Information Flow Optimization: Insights from a Phishing Detection Case Study.

**Traditional phishing detection and generalisation**

- Zieni et al. (2023), Phishing or Not Phishing? A Survey on the Detection of Phishing Websites.
- Asiri et al. (2023), A Survey of Intelligent Detection Designs of HTML URL Phishing Attacks.
- Rashid et al. (2024), Phishing URL Detection Generalisation Using Unsupervised Domain Adaptation.
- URLTran (2021).
- Phishpedia (2021).
- PhishTransformer (2024).
- PhiUSIIL (2024).
- Relevant cross-dataset and feature-engineering studies from 2025–2026.

Previously identified DOIs and links must be independently checked before being cited in academic work. Do not assume every earlier bibliographic detail or reported result is correct.

### 6. Existing research limitations

Do not claim that the following are novel by themselves:

- ML followed by an LLM.
- Two-stage classification.
- Learning to defer.
- Confidence-based routing.
- Calibration-based escalation.
- Selective classification.
- Conformal prediction.
- Distribution-shift-aware selective classification.
- Cost-aware LLM routing.
- Sequential information acquisition.
- Evidence selection.
- Asymmetric error costs.
- Budget constraints.

These areas already have research coverage.

The candidate research gap is:

Whether a phishing-specific framework can jointly manage final-system false-negative risk, limited AI inference expenditure, distribution changes, uncertainty in the escalation policy and errors made by the AI expert, with a defensible evaluation and explicit assumptions.

This gap has NOT yet been proven.

### 7. Possible datasets

Potential sources include:

- PhiUSIIL UCI dataset, DOI: 10.24432/C56K77.
- PhishTank.
- OpenPhish.
- Tranco benign-domain list.
- Other independently collected or published phishing datasets.

Do not select datasets merely because they are popular.

Investigate:

- Label provenance.
- Dataset age.
- Timestamp availability.
- URL availability.
- Feature availability.
- Dataset licensing.
- Duplicate URLs.
- Domain overlap.
- Campaign overlap.
- Temporal leakage.
- Train/test contamination.
- Cross-dataset compatibility.

Clearly distinguish features that are available from the URL alone from those requiring webpage access, DNS queries or external services.

### 8. Experimental requirements

The final research must compare against relevant baselines, potentially including:

1. ML-only.
2. Fixed-confidence-threshold ML + AI.
3. Existing learning-to-defer.
4. Relevant cost-constrained deferral.
5. Relevant conformal/selective-risk method.
6. Proposed method.

Evaluation should consider:

- Random split.
- Domain-disjoint split.
- Cross-dataset evaluation.
- Temporal evaluation if reliable timestamps exist.
- Distribution-shift evaluation.
- Adversarial URL mutations.
- Calibration and OOD performance.
- Fixed AI inference budgets.

Metrics should include:

- Accuracy.
- Precision.
- Recall.
- F1.
- PR-AUC.
- False-positive rate.
- False-negative rate.
- ECE.
- Brier score.
- Selective risk.
- Coverage.
- Escalation rate.
- AI calls per 1,000 URLs.
- Input, output and total tokens.
- Actual or estimated inference cost.
- Median and p95 latency.
- Throughput.

Explicitly measure phishing URLs incorrectly classified as legitimate, phishing cases recovered by Stage 2, legitimate URLs unnecessarily escalated, and legitimate URLs incorrectly flagged.

Never report simulated AI results as real provider results.

### 9. Development constraints

- I use Windows.
- I use VS Code and Antigravity CLI.
- Prefer free and locally runnable tools.
- Avoid unnecessary paid APIs.
- Python is the preferred implementation language.
- Stage 1 must work independently without live AI credentials.
- Possible Stage 2 providers may include Groq, Gemini or a local model, but no provider is finalised.

I prefer detailed, understandable, step-by-step guidance.

I want to understand what I am building so I can defend it to my mentor.

### 10. Mandatory working rules

1. Research before coding.
2. Verify papers using primary sources.
3. Prefer full papers over abstracts.
4. Include IEEE, ACM, Springer, Elsevier, Wiley, MDPI, reputable conferences, arXiv where appropriate and other credible sources.
5. Do not restrict the research to IEEE Xplore.
6. Never invent citations, results, equations or research gaps.
7. Distinguish published findings from your own proposed ideas.
8. Challenge my assumptions.
9. Do not claim novelty without a direct literature comparison.
10. Do not generate implementation prompts until the research and architecture are approved.
11. Ask me for approval at major decision gates.
12. If the proposed research gap is not defensible, tell me honestly and recommend a better direction.

### Your first task

Do not start coding.

First acknowledge this context, identify the current research stage, and continue with PROMPT 2 below when I provide it.